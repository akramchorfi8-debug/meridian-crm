/*
# Meridian Initial Schema

1. New Tables
- `profiles` - User profile information extending auth.users
  - id (uuid, primary key, references auth.users)
  - full_name (text)
  - phone (text)
  - country_code (text)
  - avatar_url (text)
  - role (text, either 'client' or 'provider')
  - created_at, updated_at (timestamps)
- `services` - Service offerings
  - id, name, description, duration_minutes, price, image_url, created_at
- `providers` - Service provider profiles
  - id, user_id (references profiles), bio, specialties, is_available, rating, created_at
- `provider_services` - Many-to-many relationship between providers and services
- `appointments` - Booking records
  - id, client_id, provider_id, service_id, date, time, status, notes, amount, created_at
- `messages` - In-app messaging
  - id, appointment_id, sender_id, content, attachments, read_at, created_at
- `payments` - Payment records
  - id, user_id, amount, currency, status, payment_method, stripe_id, created_at
- `payouts` - Provider payout records
  - id, provider_id, amount, status, bank_info, created_at
- `media_gallery` - Provider media content
  - id, provider_id, type, url, thumbnail_url, caption, created_at

2. Security
- RLS enabled on all tables
- Owner-scoped policies for authenticated users
- Profiles accessible to owner only
- Messages scoped by appointment participation
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Profiles table (extends auth.users)
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  phone text,
  country_code text DEFAULT '+1',
  avatar_url text,
  role text NOT NULL DEFAULT 'client' CHECK (role IN ('client', 'provider', 'admin')),
  bio text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Services table
CREATE TABLE IF NOT EXISTS services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  duration_minutes int NOT NULL DEFAULT 60,
  price decimal(10,2) NOT NULL,
  image_url text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE services ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "services_read" ON services;
CREATE POLICY "services_read" ON services FOR SELECT
  TO anon, authenticated USING (is_active = true);

-- Providers table
CREATE TABLE IF NOT EXISTS providers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(user_id) ON DELETE CASCADE,
  bio text,
  specialties text[] DEFAULT '{}',
  is_available boolean DEFAULT true,
  rating decimal(3,2) DEFAULT 5.0,
  total_reviews int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE providers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "providers_read" ON providers;
CREATE POLICY "providers_read" ON providers FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "providers_insert" ON providers;
CREATE POLICY "providers_insert" ON providers FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "providers_update" ON providers;
CREATE POLICY "providers_update" ON providers FOR UPDATE
  TO authenticated USING (user_id IN (SELECT user_id FROM profiles WHERE auth.uid() = user_id));

-- Provider-services junction table
CREATE TABLE IF NOT EXISTS provider_services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id uuid REFERENCES providers(id) ON DELETE CASCADE,
  service_id uuid REFERENCES services(id) ON DELETE CASCADE,
  custom_price decimal(10,2),
  UNIQUE(provider_id, service_id)
);

ALTER TABLE provider_services ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "provider_services_read" ON provider_services;
CREATE POLICY "provider_services_read" ON provider_services FOR SELECT
  TO anon, authenticated USING (true);

-- Appointments table
CREATE TABLE IF NOT EXISTS appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  provider_id uuid NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
  service_id uuid NOT NULL REFERENCES services(id),
  appointment_date date NOT NULL,
  appointment_time time NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled')),
  notes text,
  amount decimal(10,2) NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "appointments_read" ON appointments;
CREATE POLICY "appointments_read" ON appointments FOR SELECT
  TO authenticated USING (
    client_id IN (SELECT id FROM profiles WHERE user_id = auth.uid())
    OR provider_id IN (SELECT id FROM providers WHERE user_id IN (SELECT user_id FROM profiles WHERE user_id = auth.uid()))
  );

DROP POLICY IF EXISTS "appointments_insert" ON appointments;
CREATE POLICY "appointments_insert" ON appointments FOR INSERT
  TO authenticated WITH CHECK (client_id IN (SELECT id FROM profiles WHERE user_id = auth.uid()));

DROP POLICY IF EXISTS "appointments_update" ON appointments;
CREATE POLICY "appointments_update" ON appointments FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- Messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id uuid NOT NULL REFERENCES appointments(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  attachments jsonb DEFAULT '[]',
  read_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "messages_read" ON messages;
CREATE POLICY "messages_read" ON messages FOR SELECT
  TO authenticated USING (
    appointment_id IN (
      SELECT id FROM appointments 
      WHERE client_id IN (SELECT id FROM profiles WHERE user_id = auth.uid())
      OR provider_id IN (SELECT id FROM providers WHERE user_id IN (SELECT user_id FROM profiles WHERE user_id = auth.uid()))
    )
  );

DROP POLICY IF EXISTS "messages_insert" ON messages;
CREATE POLICY "messages_insert" ON messages FOR INSERT
  TO authenticated WITH CHECK (sender_id IN (SELECT id FROM profiles WHERE user_id = auth.uid()));

-- Payments table
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
  amount decimal(10,2) NOT NULL,
  currency text DEFAULT 'USD',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed', 'refunded')),
  payment_method text,
  stripe_payment_intent_id text,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "payments_read" ON payments;
CREATE POLICY "payments_read" ON payments FOR SELECT
  TO authenticated USING (user_id IN (SELECT user_id FROM profiles WHERE auth.uid() = user_id));

DROP POLICY IF EXISTS "payments_insert" ON payments;
CREATE POLICY "payments_insert" ON payments FOR INSERT
  TO authenticated WITH CHECK (user_id IN (SELECT user_id FROM profiles WHERE auth.uid() = user_id));

-- Payouts table
CREATE TABLE IF NOT EXISTS payouts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id uuid NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
  amount decimal(10,2) NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  bank_last4 text,
  created_at timestamptz DEFAULT now(),
  processed_at timestamptz
);

ALTER TABLE payouts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "payouts_read" ON payouts;
CREATE POLICY "payouts_read" ON payouts FOR SELECT
  TO authenticated USING (provider_id IN (SELECT id FROM providers WHERE user_id IN (SELECT user_id FROM profiles WHERE user_id = auth.uid())));

DROP POLICY IF EXISTS "payouts_insert" ON payouts;
CREATE POLICY "payouts_insert" ON payouts FOR INSERT
  TO authenticated WITH CHECK (provider_id IN (SELECT id FROM providers WHERE user_id IN (SELECT user_id FROM profiles WHERE user_id = auth.uid())));

-- Media Gallery table
CREATE TABLE IF NOT EXISTS media_gallery (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id uuid NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('image', 'video')),
  url text NOT NULL,
  thumbnail_url text,
  caption text,
  sort_order int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE media_gallery ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "media_gallery_read" ON media_gallery;
CREATE POLICY "media_gallery_read" ON media_gallery FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "media_gallery_insert" ON media_gallery;
CREATE POLICY "media_gallery_insert" ON media_gallery FOR INSERT
  TO authenticated WITH CHECK (provider_id IN (SELECT id FROM providers WHERE user_id IN (SELECT user_id FROM profiles WHERE user_id = auth.uid())));

DROP POLICY IF EXISTS "media_gallery_delete" ON media_gallery;
CREATE POLICY "media_gallery_delete" ON media_gallery FOR DELETE
  TO authenticated USING (provider_id IN (SELECT id FROM providers WHERE user_id IN (SELECT user_id FROM profiles WHERE user_id = auth.uid())));

-- Insert default services
INSERT INTO services (name, description, duration_minutes, price, image_url) VALUES
('Haircut & Styling', 'Professional haircut with styling consultation', 45, 55.00, 'https://images.pexels.com/photos/1813272/pexels-photo-1813272.jpeg?auto=compress&cs=tinysrgb&w=400'),
('Full Color Treatment', 'Complete hair color transformation with premium products', 120, 180.00, 'https://images.pexels.com/photos/3997371/pexels-photo-3997371.jpeg?auto=compress&cs=tinysrgb&w=400'),
('Deep Conditioning Spa', 'Intensive hair treatment for damaged or dry hair', 60, 85.00, 'https://images.pexels.com/photos/1748795/pexels-photo-1748795.jpeg?auto=compress&cs=tinysrgb&w=400'),
('Beard Trim & Shape', 'Expert beard grooming with hot towel treatment', 30, 35.00, 'https://images.pexels.com/photos/1681011/pexels-photo-1681011.jpeg?auto=compress&cs=tinysrgb&w=400'),
('Bridal Package', 'Complete bridal hair styling including trial', 180, 320.00, 'https://images.pexels.com/photos/1692017/pexels-photo-1692017.jpeg?auto=compress&cs=tinysrgb&w=400'),
('Mens Executive Cut', 'Premium mens haircut with scalp massage', 60, 75.00, 'https://images.pexels.com/photos/1813272/pexels-photo-1813272.jpeg?auto=compress&cs=tinysrgb&w=400')
ON CONFLICT DO NOTHING;